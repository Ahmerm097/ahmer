<?php
$day = "monday"; // Get the current day of the week

switch ($day) {
    case 'Monday': case 'monday';
        echo "today is monday, special biryani";
        break;
    case 'Tuesday':
        echo "today is tuesday, special korma";
        break;
    case 'Wednesday':
        echo "today is wednesday, special pasta";
        break;
    case 'thursday':
        echo "today is thursday, special vegetable";
        break;
    case 'friday':
        echo "today is friday, special daal";
        break;
    case 'saturday':
            echo "today is saturday, special chinese ";
            break;
    case 'sunday':
            echo "today is sunday, special barbq party ";
            break;        
    default:
        echo "Day is not find";
        break;
}
?>
