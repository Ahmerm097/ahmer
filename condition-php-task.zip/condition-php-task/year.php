<?php
$birthYear = 2000 ; // Replace with the birth year you want to use
$currentYear = date('Y'); // Get the current year
$age = 0;

echo "Birthday Year:\n";
while ($birthYear < $currentYear) {
    echo $birthYear . "<br>";
    $birthYear++;
    $age  += 1;
};
echo($age ."<br>");
?>

