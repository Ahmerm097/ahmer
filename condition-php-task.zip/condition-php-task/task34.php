<?php
$months = ["January", "February", "March", "April", "May", "June"];
$valueToRemove = "February";

echo "Original Array: <br>";
print_r($months);

foreach ($months as $key => $month) {
    if ($month === $valueToRemove) {
        unset($months[$key]);
    }
}

echo "Updated Array: <br>";
print_r($months);
?>
