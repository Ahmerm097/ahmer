<?php
echo "My name is Ahmer";
?>
