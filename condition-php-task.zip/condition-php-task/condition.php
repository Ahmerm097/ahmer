<?php
$x = 50 ;
if ($x < 40) {
    echo "x is smaller";
}
else{
    echo "x is greater";
}
?>
