<?php
$day = "tuesday"; // Get the current day of the week

if ($day == 'Friday') {
    echo "Have a nice Friday!";
} elseif ($day == 'Sunday') {
    echo "Happy weekend!";
} else {
    echo "Have a good day!";
}
?>
