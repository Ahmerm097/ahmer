<?php
$row = 8;

while ($row >= 1) {
    $column = 1;

    while ($column <= $row) {
        echo '*';
        $column++;
    }

    echo "<br>";
    $row--;
}
?>
