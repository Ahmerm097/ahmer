var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

var monthString = "";
for (var i = 0; i < months.length; i++) {
  monthString += months[i] + " ";
}

console.log(monthString);
