let role = "guest";

if (role === "guest") {
  console.log("Guest User");
} else if (role === "admin") {
  console.log("Admin User");
} else {
  console.log("Unknown User");
}