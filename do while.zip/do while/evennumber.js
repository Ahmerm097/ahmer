let i = 0; // Start with 2, as the first even number

do {
  console.log(i);
  i += 2; // Increment i by 2 to generate the next even number
} while (i <= 10);
