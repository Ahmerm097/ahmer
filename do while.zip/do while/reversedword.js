let i = 10; // Start with 9, the highest number

do {
  console.log(i);
  i--; // Decrement i by 1 to generate the previous number
} while (i >= 1);
