let i = 1; 

do {
  console.log(i);
  i += 2; 
} while (i <= 10);
