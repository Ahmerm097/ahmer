let role = "admin";
switch(role){
    case "guest":
    console.log("Guest User");
    break;
    case "admin":
    console.log("Admin User");
    break;
    default:
    console.log("Unknown User");
}

