let role = "guest";

if (role === "guest") {
  console.log("Guest User");
} 
if (role === "admin") {
  console.log("Admin User");
} 
if (role !== "guest" && role !== "admin") {
  console.log("Unknown User");
}
