const color ={
    color1:"red", 
    color2:"green",
    color3:"blue"
};
for (let key in color) {
  //console.log(key);
  console.log(key,color[key])
}