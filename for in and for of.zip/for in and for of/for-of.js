const colors = ["red", "green", "blue"];

for (let color of colors) {
  console.log(color);
}