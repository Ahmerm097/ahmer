const person = {
    name : "Ali",
    age : 21,
    roll :"student"
};
for(let key in person){
    //console.log(key);
    console.log(key,person[key]);
}


/*const person = {
  name: "Ali",
  age: 21,
  roll: "student"
};

for (let k in person) {
  console.log(k);
}*/