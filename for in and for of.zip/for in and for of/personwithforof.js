const person=["Ali",21,"student"]
for (let persons of person){
    console.log(persons)
}