let count = 0;

for (let i = 0; count < 10; i += 2) {
  console.log(i);
  count++;
}