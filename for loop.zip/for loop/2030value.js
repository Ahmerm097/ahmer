for(let i=20; i<=30; i++){
    console.log("Hello Web",i);
}