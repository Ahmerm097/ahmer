
<?php
//$students = ['Ali', 'Ahmer', 'Ahmed', 'Ali Ahmed'];
//sort($students);
//print_r($students);
?>

<?php
// $students = ['Ali', 'Ahmer', 'Ahmed', 'Ali Ahmed'];
//rsort($students);
//print_r($students);
?>

<?php
//$students = ['Ali' => 20, 'Ahmer' => 21, 'Ahmed' => 22, 'Ali Ahmed' => 23];
//asort($students);
//print_r($students);
?>
<?php
// $students = ['Ali' => 20, 'Ahmer' => 21, 'Ahmed' => 22, 'Ali Ahmed' => 23];
// arsort($students);
// print_r($students);
?>
<?php
//$students = ['Ali' => 20, 'Ahmer' => 21, 'Ahmed' => 22, 'Ali Ahmed' => 23];
//ksort($students);
//print_r($students);
?>
<?php
$students = ['Ali' => 20, 'Ahmer' => 21, 'Ahmed' => 22, 'Ali Ahmed' => 23];
krsort($students);
print_r($students);
?>


