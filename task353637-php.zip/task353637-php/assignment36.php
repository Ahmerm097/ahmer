<?php
//$str = "Laravel";
//print(ctype_lower($str));
//if (ctype_lower($str)) {
   // echo "all lower case";
//} else{
   // echo "not in lower case";
//}
?>
<?php
//$str = "LARVAL";
//if (ctype_upper($str)) {
   // echo "all upper case";
//} else{
  //  echo "not in upper case";
//}

?>

<?php
//$str = "1234";
//if (is_numeric($str)) {
  //  echo "is a number";
//} else {
  //  echo "not in number";
//}
?>

<?php
$str = "3.14";
if (is_float(floatval($str))) {
    echo "The string is a float number.";
} else {
    echo "The string is not a float number.";
}
?>

