<?php
$str = "   Laraval  ";
echo strlen($str);
?>