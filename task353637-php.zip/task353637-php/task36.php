<?php
// $str = "LARAVAL";
// echo strtolower($str);
?>

<?php
$str = "laravel";
echo strtoupper($str);
?>


